<?php

declare(strict_types=1);

namespace Doctrine\ORM\Proxy;

use Doctrine\Common\Proxy\Autoloader as BaseAutoloader;

class Autoloader extends BaseAutoloader
{
}
