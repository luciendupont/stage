<?php

declare(strict_types=1);

namespace Doctrine\ORM\Event;

final class PrePersistEventArgs extends LifecycleEventArgs
{
}
